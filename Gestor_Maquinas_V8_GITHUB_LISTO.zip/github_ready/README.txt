Proyecto Android del Gestor de Máquinas V8. Incluye workflow de GitHub Actions para generar la APK desde la nube.
